//
//  MOPUBNativeVideoCustomEvent.h
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPNativeCustomEvent.h"

@interface MOPUBNativeVideoCustomEvent : MPNativeCustomEvent

@end
