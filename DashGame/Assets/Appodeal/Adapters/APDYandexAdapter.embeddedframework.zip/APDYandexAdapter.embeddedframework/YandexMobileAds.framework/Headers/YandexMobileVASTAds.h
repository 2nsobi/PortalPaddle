/*
 * Version for iOS © 2015–2018 YANDEX
 *
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at https://yandex.com/legal/mobileads_sdk_agreement/
 */

#import <YandexMobileAds/YMAYandexVASTAds.h>
#import <YandexMobileAds/YMABlock.h>
#import <YandexMobileAds/YMABlocksInfo.h>
#import <YandexMobileAds/YMAVASTAd.h>
#import <YandexMobileAds/YMACreative.h>
#import <YandexMobileAds/YMAMediaFile.h>
#import <YandexMobileAds/YMAVASTTracker.h>
#import <YandexMobileAds/YMAVideoAdsRequest.h>
#import <YandexMobileAds/YMAErrors.h>
#import <YandexMobileAds/YMAVASTErrors.h>
#import <YandexMobileAds/YMAIcon.h>
